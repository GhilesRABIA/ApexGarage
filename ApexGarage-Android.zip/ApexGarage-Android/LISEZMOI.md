# ApexGarage pour Android

Application de garage (santé des pièces, entretien, pleins, budget, stock, diagnostic) qui fonctionne **entièrement hors ligne** sur ton téléphone. Elle n'a besoin d'aucune permission ni d'Internet.

Le fichier à installer s'appelle un **APK**. Il faut d'abord le fabriquer à partir de ce dossier. Choisis une des deux méthodes.

---

## Méthode A : GitHub fabrique l'APK pour toi (gratuit, sans rien installer)

Il te faut un compte GitHub et un ordinateur pour l'envoi des fichiers (celui d'un ami suffit, une seule fois).

1. Va sur https://github.com et crée un compte (ou connecte-toi).
2. Clique sur **+** en haut à droite, puis **New repository**. Nom : `ApexGarage`. Laisse **Public** ou choisis **Private**, puis **Create repository**.
3. Décompresse `ApexGarage-Android.zip` sur l'ordinateur.
4. Sur la page du dépôt, clique sur **uploading an existing file**. Glisse **tout le contenu** du dossier décompressé (le dossier `app`, le dossier `.github`, et les fichiers à côté). Vérifie que le dossier `.github` est bien envoyé : c'est lui qui lance la fabrication.
5. Clique sur **Commit changes**.
6. Ouvre l'onglet **Actions**. Une exécution « Compiler l'APK » démarre. Attends 4 à 8 minutes que la pastille devienne verte.
7. Si rien ne démarre : onglet **Actions**, clique sur **Compiler l'APK** à gauche, puis **Run workflow**.
8. Quand c'est vert, ouvre la page principale du dépôt. À droite, dans **Releases**, ouvre **ApexGarage (dernière version)** et télécharge **ApexGarage.apk** depuis ton téléphone.

## Méthode B : Android Studio (sur ordinateur)

1. Installe Android Studio (https://developer.android.com/studio).
2. **Open** puis choisis le dossier `ApexGarage-Android`. Accepte la mise à jour de Gradle si on te la propose.
3. Attends la fin de la synchronisation.
4. Menu **Build**, puis **Build APK(s)**. Clique sur **locate** : le fichier est dans `app/build/outputs/apk/debug/app-debug.apk`.
5. Envoie ce fichier sur ton téléphone (câble USB, Bluetooth, Drive).

---

## Installer l'APK sur le téléphone

1. Ouvre le fichier `ApexGarage.apk` depuis les Téléchargements.
2. Android demande d'autoriser l'installation depuis cette source (navigateur ou Fichiers) : accepte, puis **Installer**.
3. Si Play Protect affiche un avertissement, c'est normal pour une application qui ne vient pas du Play Store : choisis **Installer quand même**.
4. Ouvre **ApexGarage** depuis ton écran d'accueil.

Fonctionne sur Android 8.0 et plus.

## Ce qu'il faut savoir

- **Au premier lancement**, une voiture d'exemple s'affiche. Touche **Ajouter ma voiture**, puis **Supprimer l'exemple**.
- **Tes données restent sur le téléphone.** Si tu désinstalles l'application ou effaces ses données, tout disparaît.
- **Fais une sauvegarde régulière** : onglet **Atelier**, rubrique **Données**, **Exporter une sauvegarde**. Le fichier JSON va dans le dossier **Téléchargements**. Pour le remettre : **Importer une sauvegarde**.
- **Reprendre les données de la version web** : exporte la sauvegarde depuis la version web, copie le fichier sur le téléphone, puis importe-le dans l'APK.
- **Bouton retour** : il ferme la fenêtre ouverte, puis revient au Cockpit, puis quitte.
- L'APK fabriqué est signé avec une clé de test : il s'installe très bien, mais ne peut pas être publié tel quel sur le Play Store.

## Mettre à jour l'application

Le contenu de l'application est dans `app/src/main/assets/index.html`. Remplace ce fichier, envoie-le sur GitHub (méthode A) : l'APK est refabriqué tout seul. Installe le nouvel APK par-dessus l'ancien : tes données sont conservées.

## Contenu du dossier

| Élément | Rôle |
|---|---|
| `app/src/main/assets/index.html` | L'application (écrans, calculs, stockage) |
| `app/src/main/assets/fonts/` | Les polices, embarquées pour le hors ligne |
| `app/src/main/java/com/apexgarage/app/MainActivity.kt` | La coque Android : plein écran, bouton retour, export et import de sauvegarde |
| `app/src/main/res/` | Icône, couleurs, thème clair et sombre |
| `.github/workflows/apk.yml` | La fabrication automatique de l'APK |
| `build.gradle.kts`, `app/build.gradle.kts`, `settings.gradle.kts` | Réglages de compilation |
